#pragma once

#include "CoreMinimal.h"
#include "Gimmic_CY/Object/Door/DoorBase.h"
#include "SafeActor.generated.h"

UCLASS()
class WARD_ZERO_API ASafeActor : public ADoorBase
{
	GENERATED_BODY()
	
public:
	ASafeActor();

protected:
	virtual void BeginPlay() override;
	virtual void OnConstruction(const FTransform& Transform) override;

	UPROPERTY(VisibleAnywhere)
	UStaticMeshComponent* Door;

	UPROPERTY(VisibleAnywhere)
	USceneComponent* Pivot;
	
	UPROPERTY(VisibleAnywhere)
	UBoxComponent* InteractionCollisionBox;

	FRotator InitialRotation;

	float TargetYaw = -100.f;

	virtual void UpdateTimelineComp(float Output) override;
	
	UPROPERTY(EditAnywhere, BlueprintReadWrite, meta = (DisplayName = "In Items"), Category = "Setting")
	TArray<AActor*> Items;

	
	bool bVanishMagic = false;
#if WITH_EDITOR
	UFUNCTION(CallInEditor, Category = "Editor")
	void DoorVanishMagic();
	
	UFUNCTION(CallInEditor, Category = "Editor")
	void SettingItemAllSafeBox();
	
	UFUNCTION()
	void SettingItemInSafeBox(ASafeActor* Obj);
	
	UFUNCTION(CallInEditor, Category = "Editor")
	void RegistAllItemWithTag();
	
	
#endif
	UPROPERTY(EditAnywhere,BlueprintReadWrite, meta = (DisplayName = "Door Action"), Category = "Setting")
	ESingleDoorAnimationType DoorAnimationType;
	
public:
	// ===== IGimmickInterface =====
	virtual void HandleInteraction_Implementation(APrototypeCharacter* Character) override;
	
	virtual void Activate() override;
	
	UFUNCTION()
	void OnOverLapBegin(class UPrimitiveComponent* OverlappedComp, class AActor* OtherActor, class UPrimitiveComponent* OtherComp, int32 OtherBodyIndex, bool bFromSweep, const FHitResult& SweepResult);
	UFUNCTION()
	void OnOverLapEnd(class UPrimitiveComponent* OverlappedComp, class AActor* OtherActor, class UPrimitiveComponent* OtherComp, int32 OtherBodyIndex);
	
	virtual EInteractionType GetInteractionType_Implementation() const override;
	ESingleDoorAnimationType GetSingleDoorAnimationType() const;
	UPROPERTY(EditInstanceOnly, Category = "Editor")
	FName ItemTag;
#if WITH_EDITOR
	
	
	UFUNCTION()
	void RegistItem(AActor* item);
#endif
};
