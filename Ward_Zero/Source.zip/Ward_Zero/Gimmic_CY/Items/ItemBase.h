#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Actor.h"
#include "Gimmic_CY/Interface//InteractionBase.h"
#include "ItemBase.generated.h"

class UWidgetComponent;
class UStaticMeshComponent;
class UBoxComponent;

UCLASS()
class WARD_ZERO_API AItemBase : public AActor, public IInteractionBase
{
	GENERATED_BODY()
	
public:	
	AItemBase();

protected:
	virtual void BeginPlay() override;

public:	
	virtual void Tick(float DeltaTime) override;


	// ===== IGimmickInterface =====
public:
	virtual void OnIneracted_Implementation(APrototypeCharacter* Character) override;
	virtual void HandleInteraction_Implementation(APrototypeCharacter* Character) override;
	virtual bool CanBeInteracted_Implementation() const override { return true; }
	virtual EInteractionType GetInteractionType_Implementation() const override;
	UFUNCTION(BlueprintCallable)
	virtual bool SetBCanInteract(bool IsCanInteract) override;
	UFUNCTION(BlueprintCallable)
	virtual bool GetBCanInteract() const override;
	virtual void SaveActorState() const override;
	
	virtual void PostActorCreated() override;
	
	
	virtual void ShowPressEWidget_Implementation() override;
	virtual void HidePressEWidget_Implementation() override;

	// ===== SaveInterface =====
	//virtual void SaveActorState(class UWardSaveGame* SaveData) override;
	//virtual void LoadActorState(class UWardSaveGame* SaveData) override;

	FVector GetInteractionTargetLocation_Implementation() const override;

	virtual void HiddenActor();
	
	UPROPERTY(EditInstanceOnly)
	bool bDefaultInteractable = true;
	
	bool bActivated = false;
	
	FRotator GetInHandTransform() const { return InHandRotator; }
	
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Interaction")
	class UWidgetComponent* InteractWidget;
	
	UPROPERTY(EditAnywhere,BlueprintReadWrite,Category = "Default")
	FString PickUpText = "";
	
	UPROPERTY(EditAnywhere,BlueprintReadWrite,Category = "Setting")
	FString Subtitle = "";
	
	UPROPERTY(EditAnywhere,BlueprintReadWrite,Category = "Setting")
	int32 DocIdx = -1;
	
	UPROPERTY(EditAnywhere,BlueprintReadWrite,Category = "Setting")
	bool bHasDoc = false;
	
	UPROPERTY(EditAnywhere,BlueprintReadWrite,Category = "Setting")
	bool bHasSubtitle = false;
	
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Ammo Loot")
	int32 AmmoAmount = 15;
	
	virtual void ShowSubtitle() const override;
	virtual void ShowDocument() const override;
protected:
	UPROPERTY(EditInstanceOnly)
	FGuid ActorID;

	UPROPERTY()
	bool bCollected = false;

	bool bGamePlay =false;
	// Mesh
	UPROPERTY(VisibleAnywhere)
	UStaticMeshComponent* Mesh;
	
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Item Setting")
	FRotator InHandRotator;
	
	
	
	UPROPERTY(VisibleAnywhere)
	USceneComponent* PickUpPoint;

	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Components")
	class UBoxComponent* CollisionBox;

	virtual FVector GetIKTargetLocation_Implementation() const override;
	
	#if WITH_EDITOR
    	virtual void PostDuplicate(EDuplicateMode::Type DuplicateMode) override;
    	virtual void PostEditImport() override;
    	
    	UFUNCTION(CallInEditor, Category = "Editor")
    	void RegenerateAllObjectIDsInLevel();
	
		UFUNCTION(CallInEditor, Category = "Editor")
		void FindClosestSafeBoxAndRegist();
    #endif
};
