﻿#include "Weapon/Projectile/Projectile.h"
#include "Components/SphereComponent.h"
#include "Components/StaticMeshComponent.h" 
#include "GameFramework/ProjectileMovementComponent.h" 
#include "NiagaraFunctionLibrary.h"
#include "NiagaraComponent.h"
#include "Kismet/GameplayStatics.h"
#include "Weapon/Data/ProjectileData.h"
#include "PhysicalMaterials/PhysicalMaterial.h"
#include "GameplayTagContainer.h"
#include "Chaos/ChaosEngineInterface.h"
#include "Perception/AISense_Hearing.h"
#include "Character/Noise/NoiseFucLibrary/PlayerNoise.h"

AProjectile::AProjectile()
{
	CollisionComp = CreateDefaultSubobject<USphereComponent>(TEXT("SphereComp"));
	CollisionComp->InitSphereRadius(5.0f);
	CollisionComp->SetCollisionProfileName(TEXT("Projectile"));
	CollisionComp->SetUseCCD(true);
	CollisionComp->bReturnMaterialOnMove = true;
	CollisionComp->SetCollisionResponseToChannel(ECC_Pawn, ECR_Block);

	RootComponent = CollisionComp;
	CollisionComp->OnComponentHit.AddDynamic(this, &AProjectile::OnHit);

	ProjectileMesh = CreateDefaultSubobject<UStaticMeshComponent>(TEXT("ProjectileMesh"));
	ProjectileMesh->SetupAttachment(RootComponent);
	ProjectileMesh->SetCastShadow(false);

	ProjectileMovement = CreateDefaultSubobject<UProjectileMovementComponent>(TEXT("ProjectileComp"));
	ProjectileMovement->UpdatedComponent = CollisionComp;
	ProjectileMovement->bRotationFollowsVelocity = true;

	//InitializeProjectile에서 덮어씌움. 
	ProjectileMovement->InitialSpeed = 0.f;
	ProjectileMovement->MaxSpeed = 0.f;
	ProjectileMovement->ProjectileGravityScale = 0.0f;

	TracerComponent = CreateDefaultSubobject<UNiagaraComponent>(TEXT("TracerComponent"));
	TracerComponent->SetupAttachment(RootComponent);
}

void AProjectile::SetProjectileActive(bool bActive)
{
	if (bActive && !ProjectileData) return;


	bIsActive = bActive;
	// 시각적/물리적 활성화 설정
	SetActorHiddenInGame(!bActive);
	SetActorEnableCollision(bActive);
	SetActorTickEnabled(bActive);

	if (bActive)
	{
		// 물리 엔진 속도 초기화
		if (ProjectileMovement)
		{
			ProjectileMovement->Velocity = GetActorForwardVector() * ProjectileMovement->InitialSpeed;
			ProjectileMovement->Activate();
		}
		// 수명이 다하면 다시 풀로 돌려보내기 (비활성화)
		if (ProjectileData)
		{
			GetWorldTimerManager().SetTimer(DeactivateTimer, [this]() 
				{ 
					SetProjectileActive(false); 
				}, ProjectileData->LifeSpan, false
			);
		}
	}
	else
	{
		if (ProjectileMovement) ProjectileMovement->Deactivate();
		GetWorldTimerManager().ClearTimer(DeactivateTimer);
	}
}

void AProjectile::InitializeProjectile(UProjectileData* Data)
{
	if (!Data) return;
	ProjectileData = Data;

	// Projectile 데이터 에셋 기반 초기화 
	ProjectileMovement->InitialSpeed = Data->InitialSpeed;
	ProjectileMovement->MaxSpeed = Data->MaxSpeed;
	ProjectileMovement->ProjectileGravityScale = Data->GravityScale;

	// ProjectileMovement의 속도를 실제 물리 엔진에 갱신
	ProjectileMovement->Velocity = GetActorForwardVector() * Data->InitialSpeed;

	if (Data->TracerEffect && TracerComponent)
	{
		TracerComponent->SetAsset(Data->TracerEffect);
	}
}

void AProjectile::OnHit(UPrimitiveComponent* HitComp, AActor* OtherActor, UPrimitiveComponent* OtherComp, FVector NormalImpulse, const FHitResult& Hit)
{
	if (!ProjectileData || OtherActor == GetOwner() || !bIsActive) return;

	ECollisionResponse Response = OtherComp->GetCollisionResponseToChannel(ECC_GameTraceChannel2);

	if (OtherActor && OtherComp)
	{
		FVector HitLocation = Hit.ImpactPoint; 
		FString ActorName = OtherActor->GetName();
		FString CompName = OtherComp->GetName();

		if (GEngine)
		{
			FString ScreenMsg = FString::Printf(TEXT("Hit: %s (%s) at %s"), *ActorName, *CompName, *HitLocation.ToCompactString());
			GEngine->AddOnScreenDebugMessage(-1, 5.f, FColor::Red, ScreenMsg);
		}

		DrawDebugSphere(GetWorld(), HitLocation, 10.0f, 12, FColor::Red, false, 5.0f);
	}


	EPhysicalSurface SurfaceType = UGameplayStatics::GetSurfaceType(Hit);

	// 이펙트 호출 
	UNiagaraSystem* Effect = ProjectileData->ImpactEffectMap.Contains(SurfaceType)
		? ProjectileData->ImpactEffectMap[SurfaceType]
		: ProjectileData->ImpactEffectMap.FindRef(SurfaceType_Default);

	if (Effect)
	{
		UNiagaraFunctionLibrary::SpawnSystemAtLocation(GetWorld(), Effect, Hit.ImpactPoint, Hit.ImpactNormal.Rotation());
	}

	// 사운드 재생 
	if (ProjectileData->ImpactSoundMap.Contains(SurfaceType) || ProjectileData->ImpactSoundMap.Contains(SurfaceType_Default))
	{
		USoundBase* Sound = ProjectileData->ImpactSoundMap.Contains(SurfaceType)
			? ProjectileData->ImpactSoundMap[SurfaceType]
			: ProjectileData->ImpactSoundMap[SurfaceType_Default];

		if (Sound)
		{
			UGameplayStatics::PlaySoundAtLocation(this, Sound, Hit.ImpactPoint);
		}
	}

	if (ProjectileData)
	{
		UPlayerNoise::ReportNoise(
			GetWorld(),
			GetInstigator(),
			Hit.ImpactPoint,
			ProjectileData->ImpactNoiseLoudness,
			ProjectileData->ImpactNoiseRange,
			ProjectileData->ImpactNoiseTag
		);
	}

	// 데미지 처리 및 제거
	UGameplayStatics::ApplyPointDamage(OtherActor, ProjectileData->Damage, GetActorForwardVector(), Hit, GetInstigatorController(), this, ProjectileData->DamageTypeClass);

	SetProjectileActive(false);
}
