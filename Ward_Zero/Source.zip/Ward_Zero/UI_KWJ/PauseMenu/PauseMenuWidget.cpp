// PauseMenuWidget.cpp

#include "UI_KWJ/PauseMenu/PauseMenuWidget.h"
#include "UI_KWJ/PauseMenu/PauseMenuSubsystem.h"
#include "UI_KWJ/Save/SaveSubsystem.h"
#include "UI_KWJ/Options/OptionsWidget.h"
#include "UI_KWJ/Reading/DocumentSubsystem.h"
#include "UI_KWJ/Loading/LoadingScreenSubsystem.h"
#include "Components/Button.h"
#include "Kismet/GameplayStatics.h"
#include "Engine/LocalPlayer.h"
#include "GameFramework/PlayerController.h"
#include "Ward_Zero.h"

void UPauseMenuWidget::NativeOnInitialized()
{
	Super::NativeOnInitialized();

	if (BTN_Load)      BTN_Load->OnClicked.AddDynamic(this, &UPauseMenuWidget::OnLoadClicked);
	if (BTN_Documents) BTN_Documents->OnClicked.AddDynamic(this, &UPauseMenuWidget::OnDocumentsClicked);
	if (BTN_Options)   BTN_Options->OnClicked.AddDynamic(this, &UPauseMenuWidget::OnOptionsClicked);
	if (BTN_MainMenu) BTN_MainMenu->OnClicked.AddDynamic(this, &UPauseMenuWidget::OnMainMenuClicked);
	if (BTN_Resume)   BTN_Resume->OnClicked.AddDynamic(this, &UPauseMenuWidget::OnResumeClicked);
}

void UPauseMenuWidget::NativeConstruct()
{
	Super::NativeConstruct();
}

FReply UPauseMenuWidget::NativeOnKeyDown(const FGeometry& InGeometry, const FKeyEvent& InKeyEvent)
{
	if (InKeyEvent.GetKey() == EKeys::Escape)
	{
		// 설정 창이 열려있으면 설정부터 닫기
		if (OptionsWidget && OptionsWidget->IsVisible())
		{
			OptionsWidget->SetVisibility(ESlateVisibility::Collapsed);
			SetVisibility(ESlateVisibility::Visible);
			return FReply::Handled();
		}

		// 로드 UI가 열려있으면 로드부터 닫기
		USaveSubsystem* SaveSys = GetOwningLocalPlayer()->GetSubsystem<USaveSubsystem>();
		if (SaveSys && SaveSys->IsLoadUIOpen())
		{
			SaveSys->HideLoadUI();
			SetVisibility(ESlateVisibility::Visible);
			return FReply::Handled();
		}

		// 서류 컬렉션이 열려있으면 닫기
		UDocumentSubsystem* DocSys = GetOwningLocalPlayer()->GetSubsystem<UDocumentSubsystem>();
		if (DocSys && DocSys->IsCollectionOpen())
		{
			DocSys->HideCollection();
			SetVisibility(ESlateVisibility::Visible);
			return FReply::Handled();
		}

		// 아무것도 안 열려있으면 PauseMenu 닫기
		OnResumeClicked();
		return FReply::Handled();
	}

	return Super::NativeOnKeyDown(InGeometry, InKeyEvent);
}

// ════════════════════════════════════════════════════════
//  버튼 콜백
// ════════════════════════════════════════════════════════

void UPauseMenuWidget::OnResumeClicked()
{
	UPauseMenuSubsystem* PauseSys = GetOwningLocalPlayer()->GetSubsystem<UPauseMenuSubsystem>();
	if (PauseSys)
	{
		PauseSys->HidePauseMenu();
	}
}

void UPauseMenuWidget::OnLoadClicked()
{
	UE_LOG(LogWard_Zero, Log, TEXT("일시정지: 불러오기"));

	SetVisibility(ESlateVisibility::Collapsed);

	USaveSubsystem* SaveSys = GetOwningLocalPlayer()->GetSubsystem<USaveSubsystem>();
	if (SaveSys)
	{
		SaveSys->ShowLoadUI();
	}
}

void UPauseMenuWidget::OnDocumentsClicked()
{
	UE_LOG(LogWard_Zero, Log, TEXT("일시정지: 서류 수집"));

	SetVisibility(ESlateVisibility::Collapsed);

	UDocumentSubsystem* DocSys = GetOwningLocalPlayer()->GetSubsystem<UDocumentSubsystem>();
	if (DocSys)
	{
		DocSys->ShowCollection();
	}
}

void UPauseMenuWidget::OnOptionsClicked()
{
	UE_LOG(LogWard_Zero, Log, TEXT("일시정지: 옵션"));

	if (!IsValid(OptionsWidget))
	{
		TSubclassOf<UOptionsWidget> OptionsClass = LoadClass<UOptionsWidget>(
			nullptr,
			TEXT("/Game/UI/Option/WBP_Options.WBP_Options_C")
		);

		if (!OptionsClass)
		{
			UE_LOG(LogWard_Zero, Error, TEXT("WBP_Options를 찾을 수 없습니다!"));
			return;
		}

		APlayerController* PC = GetOwningPlayer();
		if (!PC) return;

		OptionsWidget = CreateWidget<UOptionsWidget>(PC, OptionsClass);
		if (OptionsWidget)
		{
			OptionsWidget->AddToViewport(410);
		}
	}
	else
	{
		// IsValid하지만 뷰포트에 없으면 다시 추가
		if (!OptionsWidget->IsInViewport())
		{
			OptionsWidget->AddToViewport(410);
		}
	}

	if (OptionsWidget)
	{
		OptionsWidget->bIsMainMenuMode = true;
		OptionsWidget->SetVisibility(ESlateVisibility::Visible);
	}
}

void UPauseMenuWidget::OnMainMenuClicked()
{
	UE_LOG(LogWard_Zero, Log, TEXT("일시정지: 메인 메뉴로"));

	// 일시정지 해제
	UGameplayStatics::SetGamePaused(GetWorld(), false);
	SetVisibility(ESlateVisibility::Collapsed);

	// 로딩 화면 표시
	if (ULocalPlayer* LP = GetOwningLocalPlayer())
	{
		if (ULoadingScreenSubsystem* LoadingSys = LP->GetSubsystem<ULoadingScreenSubsystem>())
		{
			LoadingSys->ShowLoading(FText::FromString(TEXT("Loading...")));
		}
	}

	// 메인 메뉴로 이동
	if (UWorld* W = GetWorld())
	{
		W->ServerTravel("/Game/UI/Demo", true);
	}
}
