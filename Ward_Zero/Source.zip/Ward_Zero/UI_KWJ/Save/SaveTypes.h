// Fill out your copyright notice in the Description page of Project Settings.

// SaveTypes.h
// FSaveFileInfo ����ü ��ȯ ���� ������ ���� ���� ����� �и�

#pragma once

#include "CoreMinimal.h"
#include "Engine/Texture2D.h"
#include "SaveTypes.generated.h"

USTRUCT(BlueprintType)
struct FSaveFileInfo
{
	GENERATED_BODY()

	UPROPERTY(BlueprintReadOnly)
	FString SlotName;

	UPROPERTY(BlueprintReadOnly)
	FString DisplayName;

	UPROPERTY(BlueprintReadOnly)
	FDateTime SaveDateTime;

	UPROPERTY(BlueprintReadOnly)
	float PlayTimeSeconds = 0.f;

	UPROPERTY(BlueprintReadOnly)
	FName LevelName;

	UPROPERTY(BlueprintReadOnly)
	UTexture2D* Thumbnail = nullptr;
};
