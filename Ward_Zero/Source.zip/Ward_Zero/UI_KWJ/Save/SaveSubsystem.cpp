// SaveSubsystem.cpp

#include "UI_KWJ/Save/SaveSubsystem.h"
#include "UI_KWJ/Save/WardSaveGame.h"
#include "WardGameInstanceSubsystem.h"
#include "UI_KWJ/Save/SaveWidget.h"
#include "UI_KWJ/Save/LoadWidget.h"
#include "UI_KWJ/GameOver/GameOverSubsystem.h"
#include "UI_KWJ/Loading/LoadingScreenSubsystem.h"
#include "Level_YC/EnvManager.h"
#include "Character/Prototype_Character/PrototypeCharacter.h"
#include "Character/Components/Status/PlayerStatusComponent.h"
#include "Character/Components/Combat/PlayerCombatComponent.h"
#include "Weapon/Weapon.h"
#include "Kismet/GameplayStatics.h"
#include "GameFramework/PlayerController.h"
#include "Engine/LocalPlayer.h"
#include "Engine/Texture2D.h"
#include "Engine/GameViewportClient.h"
#include "ImageUtils.h"
#include "IImageWrapper.h"
#include "IImageWrapperModule.h"
#include "RenderingThread.h"
#include "Misc/FileHelper.h"
#include "HAL/PlatformFileManager.h"
#include "Ward_Zero.h"

const FString USaveSubsystem::SavePrefix = TEXT("WardZero_");

void USaveSubsystem::Initialize(FSubsystemCollectionBase& Collection)
{
	Super::Initialize(Collection);

	// 레벨 로드 완료 시 PendingSaveData 적용 콜백 등록
	// AddUObject: this가 파괴되면 콜백 자동 무시 (AddLambda보다 안전)
	OnLevelLoadedHandle = FCoreUObjectDelegates::PostLoadMapWithWorld.AddUObject(
		this, &USaveSubsystem::OnLevelLoaded);

	UE_LOG(LogWard_Zero, Log, TEXT("SaveSubsystem 초기화 완료"));
}

void USaveSubsystem::OnLevelLoaded(UWorld* LoadedWorld)
{
	UGameInstance* GI = GetLocalPlayer()->GetGameInstance();
	if (!GI) return;

	UWardGameInstanceSubsystem* SaveGI = GI->GetSubsystem<UWardGameInstanceSubsystem>();
	if (!SaveGI) return;

	// 레벨 전환 시 옵션 값 재적용 (볼륨 등)
	SaveGI->ApplyOptions(LoadedWorld);

	UWardSaveGame* DataToApply = SaveGI->GetPendingSaveData();
	if (!DataToApply) return;

	// 한 틱 뒤에 적용 (레벨 액터들이 완전히 초기화된 후)
	if (UWorld* World = GetWorld())
	{
		World->GetTimerManager().SetTimerForNextTick([this, SaveGI, DataToApply]()
		{
			ApplyGameState(DataToApply);
			SaveGI->ClearPendingSaveData();
			UE_LOG(LogWard_Zero, Log, TEXT("레벨 전환 후 세이브 데이터 적용 완료"));
		});
	}
}

void USaveSubsystem::Deinitialize()
{
	// 콜백 해제 — 서브시스템 파괴 후 콜백이 호출되면 크래시 발생
	FCoreUObjectDelegates::PostLoadMapWithWorld.Remove(OnLevelLoadedHandle);

	// 스크린샷 콜백 해제
	if (ScreenshotDelegateHandle.IsValid())
	{
		if (UGameViewportClient* ViewportClient = GetWorld() ? GetWorld()->GetGameViewport() : nullptr)
		{
			ViewportClient->OnScreenshotCaptured().Remove(ScreenshotDelegateHandle);
		}
		ScreenshotDelegateHandle.Reset();
	}

	Super::Deinitialize();
}

// ════════════════════════════════════════════════════════
//  저장
// ════════════════════════════════════════════════════════

void USaveSubsystem::SaveGame(const FString& SlotName)
{
	UWardSaveGame* SaveData = CollectCurrentGameState();
	if (!SaveData)
	{
		UE_LOG(LogWard_Zero, Error, TEXT("세이브 데이터 수집 실패"));
		return;
	}

	FString FinalSlotName = SlotName.IsEmpty() ? GenerateSlotName() : SlotName;


	SaveData->PlayTimeSeconds = UGameplayStatics::GetRealTimeSeconds(GetWorld());

	UGameplayStatics::SaveGameToSlot(SaveData, SavePrefix + FinalSlotName, 0);


	SaveData->DisplayName = FinalSlotName;

	// 캐시된 스크린샷 사용 (ShowSaveUI에서 비동기 캡처)
	if (CachedScreenshotData.Num() > 0)
	{
		SaveData->ScreenshotData = CachedScreenshotData;
		SaveData->ScreenshotWidth = CachedScreenshotWidth;
		SaveData->ScreenshotHeight = CachedScreenshotHeight;
	}
	else
	{
		UE_LOG(LogWard_Zero, Warning, TEXT("스크린샷 캐시가 비어있음 — 썸네일 없이 저장"));
	}

	if (UGameplayStatics::SaveGameToSlot(SaveData, SavePrefix + FinalSlotName, 0))
	{
		LastSaveSlotName = FinalSlotName;
		UE_LOG(LogWard_Zero, Log, TEXT("세이브 성공: %s"), *FinalSlotName);
	}
	else
	{
		UE_LOG(LogWard_Zero, Error, TEXT("세이브 실패: %s"), *FinalSlotName);
	}
}

// ════════════════════════════════════════════════════════
//  로드
// ════════════════════════════════════════════════════════

bool USaveSubsystem::LoadGame(const FString& SlotName)
{
	FString FullSlotName = SavePrefix + SlotName;

	if (!UGameplayStatics::DoesSaveGameExist(FullSlotName, 0))
	{
		UE_LOG(LogWard_Zero, Warning, TEXT("세이브 파일 없음: %s"), *SlotName);
		return false;
	}

	UWardSaveGame* SaveData = Cast<UWardSaveGame>(
		UGameplayStatics::LoadGameFromSlot(FullSlotName, 0)
	);

	if (!SaveData)
	{
		UE_LOG(LogWard_Zero, Error, TEXT("세이브 로드 실패: %s"), *SlotName);
		return false;
	}

	// GameOver UI가 열려 있으면 닫기
	if (UGameOverSubsystem* GameOverSys = GetLocalPlayer()->GetSubsystem<UGameOverSubsystem>())
	{
		if (GameOverSys->IsGameOver())
		{
			GameOverSys->HideGameOver();
		}
	}

	// 로드 시 Save/Load UI 모두 닫기
	HideSaveUI();
	HideLoadUI();

	// 로딩 화면 표시
	if (ULoadingScreenSubsystem* LoadingSys = GetLocalPlayer()->GetSubsystem<ULoadingScreenSubsystem>())
	{
		LoadingSys->ShowLoading(FText::FromString(TEXT("Loading...")));
	}

	// 항상 ServerTravel — 맵 리로드로 모든 액터 BeginPlay 보장
	// → 각 액터가 GameInstanceSubsystem에서 자기 GUID로 상태 복원
	UGameInstance* GI = GetLocalPlayer()->GetGameInstance();
	if (GI)
	{
		if (UWardGameInstanceSubsystem* SaveGI = GI->GetSubsystem<UWardGameInstanceSubsystem>())
		{
			SaveGI->SetPendingSaveData(SaveData);
		}
	}

	FName CurrentLevel = FName(*UGameplayStatics::GetCurrentLevelName(GetWorld()));
	FString TravelURL = (SaveData->CurrentLevelName != NAME_None)
		? SaveData->CurrentLevelName.ToString()
		: CurrentLevel.ToString();

	UE_LOG(LogWard_Zero, Log, TEXT("세이브 로드 → ServerTravel: %s"), *TravelURL);
	GetWorld()->ServerTravel(TravelURL, true);

	return true;
}

bool USaveSubsystem::LoadLastSave()
{
	if (LastSaveSlotName.IsEmpty())
	{
		// 마지막 세이브가 없으면 목록에서 최신 것을 찾기
		TArray<FSaveFileInfo> Saves = GetSaveFileList();
		if (Saves.Num() > 0)
		{
			return LoadGame(Saves[0].SlotName);
		}

		UE_LOG(LogWard_Zero, Warning, TEXT("로드할 세이브가 없습니다"));
		return false;
	}

	return LoadGame(LastSaveSlotName);
}

// ════════════════════════════════════════════════════════
//  삭제
// ════════════════════════════════════════════════════════

bool USaveSubsystem::DeleteSave(const FString& SlotName)
{
	FString FullSlotName = SavePrefix + SlotName;

	if (UGameplayStatics::DeleteGameInSlot(FullSlotName, 0))
	{
		UE_LOG(LogWard_Zero, Log, TEXT("세이브 삭제: %s"), *SlotName);
		return true;
	}

	UE_LOG(LogWard_Zero, Warning, TEXT("세이브 삭제 실패: %s"), *SlotName);
	return false;
}

// ════════════════════════════════════════════════════════
//  목록
// ════════════════════════════════════════════════════════

TArray<FSaveFileInfo> USaveSubsystem::GetSaveFileList()
{
	TArray<FSaveFileInfo> Result;

	FString SaveDir = FPaths::ProjectSavedDir() / TEXT("SaveGames");
	TArray<FString> FoundFiles;
	IFileManager::Get().FindFiles(FoundFiles, *SaveDir, TEXT(".sav"));

	for (const FString& FileName : FoundFiles)
	{
		FString BaseName = FPaths::GetBaseFilename(FileName);
		if (!BaseName.StartsWith(SavePrefix))
		{
			continue;
		}

		UWardSaveGame* SaveData = Cast<UWardSaveGame>(
			UGameplayStatics::LoadGameFromSlot(BaseName, 0)
		);

		if (SaveData)
		{
			FSaveFileInfo Info;
			Info.SlotName = BaseName.RightChop(SavePrefix.Len());
			Info.DisplayName = SaveData->DisplayName;
			Info.SaveDateTime = SaveData->SaveDateTime;
			Info.PlayTimeSeconds = SaveData->PlayTimeSeconds;
			Info.LevelName = SaveData->CurrentLevelName;

			if (SaveData->ScreenshotData.Num() > 0)
			{
				Info.Thumbnail = CreateThumbnailFromPNG(
					SaveData->ScreenshotData,
					SaveData->ScreenshotWidth,
					SaveData->ScreenshotHeight
				);
			}

			Result.Add(Info);
		}
	}

	Result.Sort([](const FSaveFileInfo& A, const FSaveFileInfo& B)
	{
		return A.SaveDateTime > B.SaveDateTime;
	});

	return Result;
}

// ════════════════════════════════════════════════════════
//  게임 상태 수집
// ════════════════════════════════════════════════════════

UWardSaveGame* USaveSubsystem::CollectCurrentGameState()
{
	UWardSaveGame* SaveData = NewObject<UWardSaveGame>();

	APlayerController* PC = GetLocalPlayer()->GetPlayerController(GetWorld());
	if (!PC) return nullptr;

	APrototypeCharacter* Character = Cast<APrototypeCharacter>(PC->GetPawn());
	if (!Character) return nullptr;

	// 위치 & 회전
	SaveData->PlayerLocation = Character->GetActorLocation();
	SaveData->PlayerRotation = PC->GetControlRotation();

	// 체력 & 스태미나
	UPlayerStatusComponent* Status = Character->FindComponentByClass<UPlayerStatusComponent>();
	if (Status)
	{
		SaveData->CurrentHealth = Status->CurrHealth;
		SaveData->MaxHealth = Status->MaxHealth;
		SaveData->CurrentStamina = Status->CurrStamina;
		SaveData->MaxStamina = Status->MaxStamina;
		SaveData->bIsExhausted = Status->bIsExhausted;
		SaveData->HealingItemCount = Status->HealingItemCount;
	}

	// 무기 & 탄약 (권총 + SMG 각각 저장)
	UPlayerCombatComponent* Combat = Character->FindComponentByClass<UPlayerCombatComponent>();
	if (Combat)
	{
		SaveData->bIsWeaponEquipped = (Combat->GetEquippedWeapon() != nullptr);

		// 권총
		if (Combat->PistolWeapon)
		{
			SaveData->CurrentAmmo = Combat->PistolWeapon->GetCurrentAmmo();
			SaveData->MaxAmmoCapacity = Combat->PistolWeapon->GetMaxCapacity();
			SaveData->ReserveAmmo = Combat->PistolWeapon->GetReserveAmmo();
		}

		// SMG
		if (Combat->SMGWeapon)
		{
			SaveData->SMGCurrentAmmo = Combat->SMGWeapon->GetCurrentAmmo();
			SaveData->SMGMaxAmmoCapacity = Combat->SMGWeapon->GetMaxCapacity();
			SaveData->SMGReserveAmmo = Combat->SMGWeapon->GetReserveAmmo();
		}
	}

	// 손전등
	SaveData->bIsFlashLightOn = Character->GetIsUseFlashLight();

	// 레벨 & 시간
	SaveData->CurrentLevelName = FName(*UGameplayStatics::GetCurrentLevelName(GetWorld()));
	SaveData->SaveDateTime = FDateTime::Now();

	// 오브젝트 상태 + 스테이지 (GameInstanceSubsystem → 세이브 데이터)
	UGameInstance* GI = GetLocalPlayer()->GetGameInstance();
	if (GI)
	{
		if (UWardGameInstanceSubsystem* SaveGI = GI->GetSubsystem<UWardGameInstanceSubsystem>())
		{
			SaveData->PlayTimeSeconds = SaveGI->GetTotalPlayTime();
			SaveData->ObjectStates = SaveGI->GetRuntimeObjectStates();
			SaveData->StageIndex = SaveGI->GetCurrentStage();
			SaveData->DefeatedBosses = SaveGI->GetDefeatedBosses();
			SaveData->CollectedDocumentIndices = SaveGI->GetActiveDocumentIndices();
			SaveData->NotifiedItemIndices = SaveGI->GetNotifiedItemIndices();
		}
	}

	return SaveData;
}

// ════════════════════════════════════════════════════════
//  게임 상태 적용
// ════════════════════════════════════════════════════════

void USaveSubsystem::ApplyGameState(UWardSaveGame* SaveData)
{
	if (!SaveData) return;

	UWorld* World = GetWorld();
	if (!World) return;

	APlayerController* PC = UGameplayStatics::GetPlayerController(World, 0);
	if (!PC) return;

	APrototypeCharacter* Character = Cast<APrototypeCharacter>(PC->GetPawn());
	if (!Character) return;

	// 사망 상태면 캐릭터 Revive() 호출 (래그돌/입력/콜리전 복원은 캐릭터가 처리)
	if (Character->StatusComp && Character->StatusComp->IsDead())
	{
		Character->Revive();
	}

	// 일시정지 해제 (게임오버에서 일시정지 중일 수 있음)
	UGameplayStatics::SetGamePaused(World, false);

	// 위치 & 회전
	Character->SetActorLocation(SaveData->PlayerLocation);
	PC->SetControlRotation(SaveData->PlayerRotation);

	// 체력 & 스태미나
	UPlayerStatusComponent* Status = Character->FindComponentByClass<UPlayerStatusComponent>();
	if (Status)
	{
		Status->CurrHealth = SaveData->CurrentHealth;
		Status->MaxHealth = SaveData->MaxHealth;
		Status->bIsDead = false;
		Status->CurrStamina = SaveData->CurrentStamina;
		Status->MaxStamina = SaveData->MaxStamina;
		Status->bIsExhausted = SaveData->bIsExhausted;

		// HP 비네팅 즉시 갱신
		Status->OnHealthChanged.Broadcast(Status->CurrHealth, Status->MaxHealth);

		// 힐템 수량 복원
		Status->HealingItemCount = SaveData->HealingItemCount;
		Status->OnHealingItemCountChanged.Broadcast(Status->HealingItemCount);
	}

	// 무기 탄약 복원 (권총 + SMG)
	{
		UPlayerCombatComponent* Combat = Character->FindComponentByClass<UPlayerCombatComponent>();
		if (Combat)
		{
			// 권총
			if (Combat->PistolWeapon)
			{
				Combat->PistolWeapon->SetCurrentAmmo(SaveData->CurrentAmmo);
				Combat->PistolWeapon->SetReserveAmmo(SaveData->ReserveAmmo);
				UE_LOG(LogWard_Zero, Log, TEXT("권총 탄약 복원: %d / %d"),
					SaveData->CurrentAmmo, SaveData->ReserveAmmo);
			}

			// SMG
			if (Combat->SMGWeapon)
			{
				Combat->SMGWeapon->SetCurrentAmmo(SaveData->SMGCurrentAmmo);
				Combat->SMGWeapon->SetReserveAmmo(SaveData->SMGReserveAmmo);
				UE_LOG(LogWard_Zero, Log, TEXT("SMG 탄약 복원: %d / %d"),
					SaveData->SMGCurrentAmmo, SaveData->SMGReserveAmmo);
			}
		}
	}

	// TODO: 손전등 상태 복원
	if (SaveData->bIsFlashLightOn)
	{
		UE_LOG(LogWard_Zero, Log, TEXT("손전등 ON 복원 필요"));
	}

	UE_LOG(LogWard_Zero, Log, TEXT("게임 상태 복원 — 위치: %s, HP: %.0f/%.0f, 스태미나: %.0f/%.0f"),
		*SaveData->PlayerLocation.ToString(),
		SaveData->CurrentHealth, SaveData->MaxHealth,
		SaveData->CurrentStamina, SaveData->MaxStamina);

	// 오브젝트 상태 + 스테이지 → GameInstanceSubsystem에 전달
	UGameInstance* GI = GetLocalPlayer()->GetGameInstance();
	if (GI)
	{
		if (UWardGameInstanceSubsystem* SaveGI = GI->GetSubsystem<UWardGameInstanceSubsystem>())
		{
			SaveGI->SetRuntimeObjectStates(SaveData->ObjectStates);
			SaveGI->SetCurrentStage(SaveData->StageIndex);
			SaveGI->SetDefeatedBosses(SaveData->DefeatedBosses);
			SaveGI->SetActiveDocumentIndices(SaveData->CollectedDocumentIndices);
			SaveGI->SetNotifiedItemIndices(SaveData->NotifiedItemIndices);
			SaveGI->SetAccumulatedPlayTime(SaveData->PlayTimeSeconds);
			SaveGI->ResetLevelStartTime();
		}
	}

	// 스테이지 인덱스에 따라 환경 구역 전환
	AActor* FoundActor = UGameplayStatics::GetActorOfClass(World, AEnvManager::StaticClass());
	AEnvManager* EnvManager = Cast<AEnvManager>(FoundActor);
	if (EnvManager)
	{
		EEnvZone TargetZone = EEnvZone::B1F;
		switch (SaveData->StageIndex)
		{
		case 0: case 1:
			TargetZone = EEnvZone::B1F;
			break;
		case 2: case 3: case 4: case 5:
			TargetZone = EEnvZone::F2;
			break;
		case 6: case 7: case 8:
			TargetZone = EEnvZone::F1;
			break;
		default:
			TargetZone = EEnvZone::B1F;
			break;
		}
		EnvManager->SwitchZone(TargetZone);
	}

}

// ════════════════════════════════════════════════════════
//  스크린샷
// ════════════════════════════════════════════════════════

void USaveSubsystem::RequestScreenshotCapture()
{
	UGameViewportClient* ViewportClient = GetWorld() ? GetWorld()->GetGameViewport() : nullptr;
	if (!ViewportClient)
	{
		UE_LOG(LogWard_Zero, Warning, TEXT("스크린샷: ViewportClient 없음"));
		return;
	}

	// 이전 바인딩 해제
	if (ScreenshotDelegateHandle.IsValid())
	{
		ViewportClient->OnScreenshotCaptured().Remove(ScreenshotDelegateHandle);
		ScreenshotDelegateHandle.Reset();
	}

	// 콜백 바인딩
	ScreenshotDelegateHandle = ViewportClient->OnScreenshotCaptured().AddUObject(
		this, &USaveSubsystem::HandleScreenshotCaptured);

	// 비동기 스크린샷 요청 (UI 없이)
	FScreenshotRequest::RequestScreenshot(false);
	UE_LOG(LogWard_Zero, Log, TEXT("스크린샷 비동기 요청 완료"));
}

void USaveSubsystem::HandleScreenshotCaptured(int32 Width, int32 Height, const TArray<FColor>& Bitmap)
{
	// 콜백 해제 (1회성)
	if (UGameViewportClient* ViewportClient = GetWorld() ? GetWorld()->GetGameViewport() : nullptr)
	{
		ViewportClient->OnScreenshotCaptured().Remove(ScreenshotDelegateHandle);
		ScreenshotDelegateHandle.Reset();
	}

	if (Width == 0 || Height == 0 || Bitmap.Num() == 0)
	{
		UE_LOG(LogWard_Zero, Warning, TEXT("스크린샷 콜백: 데이터 없음 (%d x %d, %d pixels)"), Width, Height, Bitmap.Num());
		return;
	}

	// 픽셀 데이터 검증
	int32 NonBlackCount = 0;
	for (int32 i = 0; i < FMath::Min(Bitmap.Num(), 1000); i++)
	{
		if (Bitmap[i].R > 0 || Bitmap[i].G > 0 || Bitmap[i].B > 0)
		{
			NonBlackCount++;
		}
	}
	UE_LOG(LogWard_Zero, Log, TEXT("스크린샷 콜백: %d x %d, 비검정=%d/1000"), Width, Height, NonBlackCount);

	// 썸네일 리사이즈
	int32 ThumbWidth = 320;
	int32 ThumbHeight = 180;
	TArray<FColor> ResizedBitmap;
	ResizedBitmap.SetNum(ThumbWidth * ThumbHeight);

	float XRatio = static_cast<float>(Width) / ThumbWidth;
	float YRatio = static_cast<float>(Height) / ThumbHeight;

	for (int32 Y = 0; Y < ThumbHeight; Y++)
	{
		for (int32 X = 0; X < ThumbWidth; X++)
		{
			int32 SrcX = FMath::Clamp(static_cast<int32>(X * XRatio), 0, Width - 1);
			int32 SrcY = FMath::Clamp(static_cast<int32>(Y * YRatio), 0, Height - 1);
			FColor Pixel = Bitmap[SrcY * Width + SrcX];
			Pixel.A = 255;
			ResizedBitmap[Y * ThumbWidth + X] = Pixel;
		}
	}

	// PNG 압축 → 캐시에 저장
	TArray64<uint8> PNGData64;
	FImageUtils::PNGCompressImageArray(ThumbWidth, ThumbHeight, ResizedBitmap, PNGData64);
	CachedScreenshotData.SetNum(PNGData64.Num());
	FMemory::Memcpy(CachedScreenshotData.GetData(), PNGData64.GetData(), PNGData64.Num());
	CachedScreenshotWidth = ThumbWidth;
	CachedScreenshotHeight = ThumbHeight;

	UE_LOG(LogWard_Zero, Log, TEXT("스크린샷 캐시 완료: %d bytes PNG"), CachedScreenshotData.Num());

	// 디버그: PNG를 파일로 저장해서 확인
	FString DebugPath = FPaths::ProjectSavedDir() / TEXT("DebugScreenshot.png");
	FFileHelper::SaveArrayToFile(CachedScreenshotData, *DebugPath);
	UE_LOG(LogWard_Zero, Log, TEXT("디버그 PNG 저장: %s"), *DebugPath);
}

UTexture2D* USaveSubsystem::CreateThumbnailFromPNG(const TArray<uint8>& PNGData, int32 Width, int32 Height)
{
	if (PNGData.Num() == 0)
	{
		UE_LOG(LogWard_Zero, Warning, TEXT("썸네일: PNG 데이터 없음"));
		return nullptr;
	}

	UTexture2D* Texture = FImageUtils::ImportBufferAsTexture2D(PNGData);
	if (!Texture)
	{
		UE_LOG(LogWard_Zero, Warning, TEXT("썸네일: ImportBufferAsTexture2D 실패"));
		return nullptr;
	}

	UE_LOG(LogWard_Zero, Log, TEXT("썸네일 생성 성공: %dx%d"), Texture->GetSizeX(), Texture->GetSizeY());
	return Texture;
}

FString USaveSubsystem::GenerateSlotName() const
{
	return FDateTime::Now().ToString(TEXT("%Y%m%d_%H%M%S"));
}

// ════════════════════════════════════════════════════════
//  세이브 UI
// ════════════════════════════════════════════════════════

void USaveSubsystem::ShowSaveUI()
{
	// UI가 뜨기 전에 비동기 스크린샷 요청
	RequestScreenshotCapture();

	USaveWidget* Widget = GetOrCreateSaveUI();
	if (Widget)
	{
		Widget->RefreshSaveList();
		Widget->SetVisibility(ESlateVisibility::Visible);
		Widget->SetKeyboardFocus();

		// 게임 일시정지
		UGameplayStatics::SetGamePaused(GetWorld(), true);

		APlayerController* PC = GetLocalPlayer()->GetPlayerController(GetWorld());
		if (PC)
		{
			FInputModeUIOnly InputMode;
			InputMode.SetWidgetToFocus(Widget->TakeWidget());
			InputMode.SetLockMouseToViewportBehavior(EMouseLockMode::DoNotLock);
			PC->SetInputMode(InputMode);
			PC->SetShowMouseCursor(true);
		}
	}
}

void USaveSubsystem::HideSaveUI()
{
	if (SaveWidget)
	{
		SaveWidget->SetVisibility(ESlateVisibility::Collapsed);
	}

	// 게임 일시정지 해제
	UGameplayStatics::SetGamePaused(GetWorld(), false);

	APlayerController* PC = GetLocalPlayer()->GetPlayerController(GetWorld());
	if (PC)
	{
		FInputModeGameOnly InputMode;
		PC->SetInputMode(InputMode);
		PC->SetShowMouseCursor(false);
	}
}

bool USaveSubsystem::IsSaveUIOpen() const
{
	return SaveWidget && SaveWidget->IsVisible();
}

// ════════════════════════════════════════════════════════
//  불러오기 UI (ESC / 게임오버용)
// ════════════════════════════════════════════════════════

void USaveSubsystem::ShowLoadUI(bool bFromGameOver, bool bFromMainMenu)
{
	ULoadWidget* Widget = GetOrCreateLoadUI();
	if (Widget)
	{
		Widget->RefreshSaveList();
		Widget->SetCloseButtonVisible(true);
		Widget->SetOpenedFromMainMenu(bFromMainMenu);
		Widget->SetOpenedFromGameOver(bFromGameOver);
		Widget->SetVisibility(ESlateVisibility::Visible);
		Widget->SetKeyboardFocus();

		APlayerController* PC = GetLocalPlayer()->GetPlayerController(GetWorld());
		if (PC)
		{
			FInputModeUIOnly InputMode;
			InputMode.SetWidgetToFocus(Widget->TakeWidget());
			InputMode.SetLockMouseToViewportBehavior(EMouseLockMode::DoNotLock);
			PC->SetInputMode(InputMode);
			PC->SetShowMouseCursor(true);
		}
	}
}

void USaveSubsystem::HideLoadUI()
{
	if (LoadWidgetInstance)
	{
		LoadWidgetInstance->SetVisibility(ESlateVisibility::Collapsed);
	}
}

bool USaveSubsystem::IsLoadUIOpen() const
{
	return LoadWidgetInstance && LoadWidgetInstance->IsVisible();
}

// ════════════════════════════════════════════════════════
//  위젯 생성
// ════════════════════════════════════════════════════════

USaveWidget* USaveSubsystem::GetOrCreateSaveUI()
{
	if (IsValid(SaveWidget))
	{
		if (!SaveWidget->IsInViewport())
		{
			SaveWidget->AddToViewport(150);
			SaveWidget->SetAnchorsInViewport(FAnchors(0.0f, 0.0f, 1.0f, 1.0f));
			SaveWidget->SetVisibility(ESlateVisibility::Collapsed);
		}
		return SaveWidget;
	}

	SaveWidget = nullptr;

	if (!SaveWidgetClass)
	{
		SaveWidgetClass = LoadClass<USaveWidget>(
			nullptr,
			TEXT("/Game/UI/Save/WBP_SaveMenu.WBP_SaveMenu_C")
		);
	}

	if (!SaveWidgetClass)
	{
		UE_LOG(LogWard_Zero, Error, TEXT("WBP_SaveMenu를 찾을 수 없습니다!"));
		return nullptr;
	}

	APlayerController* PC = GetLocalPlayer()->GetPlayerController(GetWorld());
	if (!PC) return nullptr;

	SaveWidget = CreateWidget<USaveWidget>(PC, SaveWidgetClass);
	if (SaveWidget)
	{
		SaveWidget->AddToViewport(150);
		SaveWidget->SetAnchorsInViewport(FAnchors(0.0f, 0.0f, 1.0f, 1.0f));
		SaveWidget->SetVisibility(ESlateVisibility::Collapsed);
	}

	return SaveWidget;
}

ULoadWidget* USaveSubsystem::GetOrCreateLoadUI()
{
	if (IsValid(LoadWidgetInstance))
	{
		if (!LoadWidgetInstance->IsInViewport())
		{
			LoadWidgetInstance->AddToViewport(210);
			LoadWidgetInstance->SetAnchorsInViewport(FAnchors(0.0f, 0.0f, 1.0f, 1.0f));
			LoadWidgetInstance->SetVisibility(ESlateVisibility::Collapsed);
		}
		return LoadWidgetInstance;
	}

	LoadWidgetInstance = nullptr;

	if (!LoadWidgetClass)
	{
		LoadWidgetClass = LoadClass<ULoadWidget>(
			nullptr,
			TEXT("/Game/UI/Save/WBP_LoadMenu.WBP_LoadMenu_C")
		);
	}

	if (!LoadWidgetClass)
	{
		UE_LOG(LogWard_Zero, Error, TEXT("WBP_LoadMenu를 찾을 수 없습니다!"));
		return nullptr;
	}

	APlayerController* PC = GetLocalPlayer()->GetPlayerController(GetWorld());
	if (!PC) return nullptr;

	LoadWidgetInstance = CreateWidget<ULoadWidget>(PC, LoadWidgetClass);
	if (LoadWidgetInstance)
	{
		LoadWidgetInstance->AddToViewport(210);
		LoadWidgetInstance->SetAnchorsInViewport(FAnchors(0.0f, 0.0f, 1.0f, 1.0f));
		LoadWidgetInstance->SetVisibility(ESlateVisibility::Collapsed);
	}

	return LoadWidgetInstance;
}
